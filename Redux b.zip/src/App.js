
import './App.css';
import Rout from './Router/Router';

function App() {
  return (
    <div className="App">
    <Rout/>
    </div>
  );
}

export default App;
