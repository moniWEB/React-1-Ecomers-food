import React from 'react'
import './BlogStyle.css'
import './Blogres.css'

export default function BlogCard() {
  return (
    <>
    <div className='col-lg-12 col-sm-12 onetime'>
    <h1>BLOG US</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi optio nemo, <br />
     ipsam sunt quaerat laborum accusantium blanditiis odio enim tenetur.</p>
    </div>
    </>
  )
}
