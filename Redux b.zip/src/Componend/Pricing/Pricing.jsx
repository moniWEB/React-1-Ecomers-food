import React from 'react'
import './Pricing.css'
import './Pricingres.css'

export default function Pricing() {
  return (
    <>
    <div className='col-lg-12 col-sm-12 pricingone'>
    <h1>PRICEING</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi optio nemo, <br />
     ipsam sunt quaerat laborum accusantium blanditiis odio enim tenetur.</p>
    </div>
    </>
  )
}
