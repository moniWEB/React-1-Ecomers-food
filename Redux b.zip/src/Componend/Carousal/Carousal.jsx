import React from 'react'
import './CarousalStyle.css'

export default function Carousal(){
  return (
    <>
 <h1>hello devoloper</h1>
    </>
  )
}
