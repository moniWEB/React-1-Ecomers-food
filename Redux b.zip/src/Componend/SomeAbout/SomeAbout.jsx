import React from 'react';
import './SomeAbout.css'
import './Someres.css'


export default function SomeAbout() {
  return (
    <>
    <div className='col-lg-12 col-sm-12 nonstop'>
    <h1>ABOUT US</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi optio nemo, <br />
     ipsam sunt quaerat laborum accusantium blanditiis odio enim tenetur.</p>
    </div>
    </>
  )
}
