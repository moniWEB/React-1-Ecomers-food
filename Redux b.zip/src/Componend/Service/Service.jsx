import React from 'react'
import './ServiceStyle.css'
import './Serviceres.css'

export default function Service() {
  return (
    <>
    <div className='col-lg-12 col-sm-12 elite'>
    <h1>SERVICE</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi optio nemo, <br />
     ipsam sunt quaerat laborum accusantium blanditiis odio enim tenetur.</p>
    </div>
    </>
    
  )
}
